#!/usr/bin/env python3
"""Referência em Python do classificador (espelho do IaClassificador.kt).
Uso: python3 -I prever.py modelo_ia.txt  -> roda a bateria de testes."""
import math
import sys
from treinar import normalizar, ngramas

LIMIAR = 0.80
MIN_LEN_MODELO = 4


def carregar(p):
    b, L, W, G = 0.0, set(), set(), {}
    for linha in open(p, encoding="utf-8"):
        t = linha.rstrip("\n").split("\t")
        if t[0] == "B":
            b = float(t[1])
        elif t[0] == "L":
            L.add(t[1])
        elif t[0] == "W":
            W.add(t[1])
        elif t[0] == "G":
            G[t[1]] = float(t[2])
    return b, L, W, G


def censurar(modelo, palavra):
    b, L, W, G = modelo
    w = normalizar(palavra)
    if not w:
        return False
    if w in W:
        return False
    if w in L:
        return True
    if len(w) < MIN_LEN_MODELO:
        return False
    z = b + sum(G.get(g, 0.0) for g in ngramas(w))
    return 1 / (1 + math.exp(-z)) >= LIMIAR


# frases separadas por espaço: também detecta "m e r d a"? (não: só palavra)
SIM = ["merda", "Merda", "MERDA", "m3rd4", "merdaaaa", "m.e.r.d.a", "p0rr4", "porraaa", "c4r4lh0",
       "caralhooo", "put4", "fdp", "f0d4-se", "foda-se", "bosta", "b0st4", "buc3t4", "p1r0ca",
       "arrombado", "merdinha", "putaria", "vtnc", "cuzão", "babaca", "desgraçado"]
NAO = ["cuidado", "Curitiba", "computador", "cassete", "pica-pau", "picanha", "porta", "porque",
       "bola", "casa", "obrigado", "mensagem", "culpa", "cultura", "fome", "foto", "oi", "bom",
       "portuguesa", "analista", "classe", "sapato", "paciencia", "escola", "bucha", "concerto",
       "cumprimento", "parabens", "tchau", "amanha", "documento", "cabeça", "porcelana"]

if __name__ == "__main__":
    m = carregar(sys.argv[1])
    erros = 0
    for w in SIM:
        if not censurar(m, w):
            print("FALHOU (devia censurar):", w); erros += 1
    for w in NAO:
        if censurar(m, w):
            print("FALHOU (nao devia censurar):", w); erros += 1
    print(f"{len(SIM)+len(NAO)} casos, {erros} erros")
    sys.exit(1 if erros else 0)
