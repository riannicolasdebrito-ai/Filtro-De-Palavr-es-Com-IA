#!/usr/bin/env python3
"""Treina o modelo da IA do Filtro de Palavrões e exporta para o app Android.

Uso: python3 -I treinar.py <pasta_ia> <saida_modelo.txt>
Modelo: regressão logística sobre n-gramas de caracteres (2 a 5) da palavra
já normalizada. Roda 100% no aparelho (Kotlin puro), sem internet.
"""
import math
import random
import sys
import unicodedata
from pathlib import Path

import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression

LEET = {"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"}


def normalizar(w: str) -> str:
    """Espelho EXATO de IaNormalizador.normalizar no Kotlin."""
    w = unicodedata.normalize("NFD", w.lower())
    w = "".join(c for c in w if unicodedata.category(c) != "Mn")
    w = "".join(LEET.get(c, c) for c in w)
    w = "".join(c for c in w if c.isalpha())
    out = []
    for c in w:
        if not out or out[-1] != c:
            out.append(c)
    return "".join(out)


def ngramas(w: str):
    s = "^" + w + "$"
    feats = {}
    for n in range(2, 6):
        for i in range(len(s) - n + 1):
            g = s[i:i + n]
            feats[g] = 1.0
    return feats


def ler(p):
    return [l.strip() for l in Path(p).read_text(encoding="utf-8").splitlines() if l.strip()]


SUFIXOS = ["", "s", "a", "o", "inha", "inho", "zinho", "ao", "ona", "ada", "ado", "oso", "eiro"]


def ruido(w, rng):
    sub = {"a": "4@", "e": "3", "i": "1", "o": "0", "s": "5$"}
    out = []
    for c in w:
        if c in sub and rng.random() < 0.4:
            out.append(rng.choice(sub[c]))
        else:
            out.append(c)
        if rng.random() < 0.15:
            out.append(c)
        if rng.random() < 0.08:
            out.append(rng.choice(".-_*"))
    return "".join(out)


def main():
    pasta = Path(sys.argv[1])
    saida = Path(sys.argv[2])
    pos = [normalizar(w) for w in ler(pasta / "data/positivos.txt")]
    neg = [normalizar(w) for w in ler(pasta / "data/negativos.txt")]
    neg = sorted(set(n for n in neg if n and n not in pos))
    pos = sorted(set(p for p in pos if p))
    rng = random.Random(7)

    X, y = [], []
    for p in pos:
        for suf in SUFIXOS:
            base = p + suf if len(p) >= 4 else p
            bases = [base]
            if len(p) >= 4 and suf and p[-1] in "aoe":
                bases.append(p[:-1] + suf)
            for base in bases:
              for k in range(3):
                X.append(ngramas(normalizar(ruido(base, rng) if k else base)))
                y.append(1)
    for n in neg:
        for suf in ("", "s", "a", "mente"):
            X.append(ngramas(normalizar(n + suf)))
            y.append(0)
        for _ in range(2):
            X.append(ngramas(normalizar(ruido(n, rng))))
            y.append(0)

    vec = DictVectorizer()
    M = vec.fit_transform(X).tocsr()
    M.indices = M.indices.astype(np.int32)
    M.indptr = M.indptr.astype(np.int32)
    y = np.array(y)
    clf = LogisticRegression(C=2.0, class_weight="balanced", max_iter=3000)
    clf.fit(M, y)
    print("acuracia treino:", clf.score(M, y), "exemplos:", len(y), file=sys.stderr)

    nomes = vec.get_feature_names_out()
    coef = clf.coef_[0]
    linhas = []
    for nome, c in zip(nomes, coef):
        if abs(c) > 1e-3:
            linhas.append(f"G\t{nome}\t{c:.4f}")
    with saida.open("w", encoding="utf-8") as f:
        f.write(f"B\t{float(clf.intercept_[0]):.4f}\n")
        for p in pos:
            f.write(f"L\t{p}\n")
        for n in neg:
            f.write(f"W\t{n}\n")
        f.write("\n".join(linhas) + "\n")
    print("n-gramas guardados:", len(linhas), file=sys.stderr)


if __name__ == "__main__":
    main()
