package com.example.filtrodepalavroes

/**
 * Filtro com IA. A decisão é do modelo local em [IaClassificador]; nenhum texto sai do aparelho.
 * Para ajustar o que é palavrão, edite ia/data/*.txt e rode ia/treinar.py de novo.
 */
object ProfanityFilter {
    fun shouldCensor(word: String): Boolean = IaClassificador.ehPalavrao(word)
}
