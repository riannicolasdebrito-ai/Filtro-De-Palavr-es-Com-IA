package com.example.filtrodepalavroes

import android.content.Context
import java.text.Normalizer
import kotlin.math.exp

/**
 * "Cérebro" do filtro: um modelo de IA pequeno (regressão logística sobre n-gramas de
 * caracteres) treinado por `ia/treinar.py` e guardado em assets/modelo_ia.txt.
 * Roda 100% no aparelho; nada é enviado para a internet.
 *
 * Passos: normaliza a palavra (acentos, leet "m3rd4", letras repetidas, pontos/hífens),
 * confere a lista segura, a lista de palavrões conhecidos e, por fim, pergunta ao modelo
 * qual a probabilidade de ser palavrão (pega variações que não estão em nenhuma lista).
 */
object IaClassificador {
    private const val LIMIAR = 0.80
    private const val TAMANHO_MINIMO_MODELO = 4

    private var bias = 0.0
    private val conhecidos = HashSet<String>()
    private val seguras = HashSet<String>()
    private val pesos = HashMap<String, Double>()

    @Volatile
    var pronto = false
        private set

    @Synchronized
    fun carregar(context: Context) {
        if (pronto) return
        try {
            context.assets.open("modelo_ia.txt").bufferedReader(Charsets.UTF_8).useLines { linhas ->
                for (linha in linhas) {
                    val p = linha.split('\t')
                    if (p.size < 2) continue
                    when (p[0]) {
                        "B" -> bias = p[1].toDouble()
                        "L" -> conhecidos.add(p[1])
                        "W" -> seguras.add(p[1])
                        "G" -> if (p.size >= 3) pesos[p[1]] = p[2].toDouble()
                    }
                }
            }
            pronto = true
        } catch (e: Exception) {
            // Sem o modelo, o filtro continua funcionando só com a lista de palavras.
            pronto = false
        }
    }

    fun probabilidade(palavra: String): Double {
        val w = normalizar(palavra)
        if (w.isEmpty() || w in seguras) return 0.0
        if (w in conhecidos) return 1.0
        if (!pronto || w.length < TAMANHO_MINIMO_MODELO) return 0.0
        val s = "^" + w + "$"
        val vistos = HashSet<String>()
        var z = bias
        for (n in 2..5) {
            for (i in 0..(s.length - n)) {
                val g = s.substring(i, i + n)
                if (vistos.add(g)) z += pesos[g] ?: 0.0
            }
        }
        return 1.0 / (1.0 + exp(-z))
    }

    fun ehPalavrao(palavra: String): Boolean = probabilidade(palavra) >= LIMIAR

    /** Deve ser idêntico a `normalizar` em ia/treinar.py. */
    fun normalizar(valor: String): String {
        val semAcento = Normalizer.normalize(valor.lowercase(), Normalizer.Form.NFD)
        val sb = StringBuilder()
        for (c0 in semAcento) {
            if (Character.getType(c0) == Character.NON_SPACING_MARK.toInt()) continue
            val c = when (c0) {
                '0' -> 'o'
                '1' -> 'i'
                '3' -> 'e'
                '4' -> 'a'
                '5' -> 's'
                '7' -> 't'
                '@' -> 'a'
                '$' -> 's'
                else -> c0
            }
            if (!c.isLetter()) continue
            if (sb.isNotEmpty() && sb[sb.length - 1] == c) continue
            sb.append(c)
        }
        return sb.toString()
    }
}
