package com.example.filtrodepalavroes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "Filtro de Palavrões"
            textSize = 27f
            setTextColor(Color.rgb(17, 24, 39))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val description = TextView(this).apply {
            text = "Um teclado com IA que troca palavrões por **** quando você termina de digitá-los, inclusive disfarçados (m3rd4, merdaaa, p0rr4). A IA roda no próprio celular e não precisa de internet."
            textSize = 16f
            setTextColor(Color.rgb(55, 65, 81))
            setPadding(0, dp(14), 0, dp(18))
        }
        root.addView(description)

        val setup = Button(this).apply {
            text = "1. Abrir configurações de teclado"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        root.addView(setup, fullWidth())

        val choose = Button(this).apply {
            text = "2. Escolher o Teclado com Filtro"
            isAllCaps = false
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        }
        root.addView(choose, fullWidth())

        val sample = TextView(this).apply {
            text = "Teste: digite um palavrão e depois um espaço ou pontuação; ele vira ****. Palavras normais (cuidado, Curitiba) passam.\n\nImportante: a IA é um modelo pequeno e pode errar em gírias novas. Ela filtra o que você digita com este teclado; não altera mensagens recebidas, áudio, imagens ou textos colados."
            textSize = 15f
            setTextColor(Color.rgb(55, 65, 81))
            setPadding(0, dp(20), 0, 0)
        }
        root.addView(sample)

        val privacy = TextView(this).apply {
            text = "Privacidade: o projeto não pede permissão de internet e não envia suas mensagens para um servidor."
            textSize = 14f
            setTextColor(Color.rgb(22, 101, 52))
            setPadding(0, dp(20), 0, 0)
        }
        root.addView(privacy)

        setContentView(root)
    }

    private fun fullWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(10) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
