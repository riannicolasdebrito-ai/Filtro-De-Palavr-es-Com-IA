package com.example.filtrodepalavroes

import android.graphics.Color
import android.content.res.ColorStateList
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FilterKeyboardService : InputMethodService() {
    private val currentWord = StringBuilder()
    private val letterButtons = mutableListOf<Pair<Button, String>>()
    private var caps = false

    override fun onCreate() {
        super.onCreate()
        IaClassificador.carregar(applicationContext)
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        if (!restarting) currentWord.clear()
    }

    override fun onCreateInputView(): View {
        letterButtons.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(4), dp(3), dp(4))
            setBackgroundColor(Color.rgb(31, 41, 55))
        }

        val header = TextView(this).apply {
            text = "IA ligada · palavrões viram ****"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(4))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(25)))

        addLetterRow(root, "qwertyuiop")
        addLetterRow(root, "asdfghjkl")

        val third = newRow()
        root.addView(third, rowParams())
        addKey(third, "⇧", 1.25f) {
            caps = !caps
            refreshCaps()
        }
        addLetters(third, "zxcvbnm")
        addKey(third, "⌫", 1.35f) { backspace() }

        addLetterRow(root, "áéíóúçãõ")

        val bottom = newRow()
        root.addView(bottom, rowParams())
        addKey(bottom, ",", 0.8f) { typeCharacter(',') }
        addKey(bottom, ".", 0.8f) { typeCharacter('.') }
        addKey(bottom, "?", 0.8f) { typeCharacter('?') }
        addKey(bottom, "!", 0.8f) { typeCharacter('!') }
        addKey(bottom, "Espaço", 3.2f) { typeCharacter(' ') }
        addKey(bottom, "↵", 1.0f) { typeCharacter('\n') }

        return root
    }

    private fun addLetterRow(root: LinearLayout, letters: String) {
        val row = newRow()
        root.addView(row, rowParams())
        addLetters(row, letters)
    }

    private fun addLetters(row: LinearLayout, letters: String) {
        letters.forEach { letter ->
            val original = letter.toString()
            val button = addKey(row, if (caps) original.uppercase() else original, 1f) {
                typeCharacter(if (caps) letter.uppercaseChar() else letter)
                if (caps) {
                    caps = false
                    refreshCaps()
                }
            }
            letterButtons.add(button to original)
        }
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
    }

    private fun rowParams() = LinearLayout.LayoutParams(-1, dp(47)).apply {
        bottomMargin = dp(3)
    }

    private fun addKey(
        row: LinearLayout,
        label: String,
        weight: Float,
        action: () -> Unit
    ): Button {
        val button = Button(this).apply {
            text = label
            textSize = if (label == "Espaço") 13f else 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(
                if (label == "Espaço") Color.rgb(75, 85, 99) else Color.rgb(55, 65, 81)
            )
            setPadding(dp(1), 0, dp(1), 0)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(0, -1, weight).apply {
            marginStart = dp(1)
            marginEnd = dp(1)
        }
        row.addView(button, params)
        return button
    }

    private fun typeCharacter(character: Char) {
        val connection: InputConnection = currentInputConnection ?: return
        val belongsToWord = character.isLetterOrDigit() || character == '-' || character == '\'' || character == '@' || character == '$'

        if (belongsToWord) {
            val actual = if (caps) character.uppercaseChar() else character
            connection.commitText(actual.toString(), 1)
            currentWord.append(actual)
            if (caps) {
                caps = false
                refreshCaps()
            }
            return
        }

        val word = currentWord.toString()
        if (word.isNotEmpty() && ProfanityFilter.shouldCensor(word)) {
            connection.deleteSurroundingText(word.length, 0)
            connection.commitText("****$character", 1)
        } else {
            connection.commitText(character.toString(), 1)
        }
        currentWord.clear()
    }

    private fun backspace() {
        val connection = currentInputConnection ?: return
        connection.deleteSurroundingText(1, 0)
        if (currentWord.isNotEmpty()) {
            currentWord.deleteCharAt(currentWord.length - 1)
        }
    }

    private fun refreshCaps() {
        letterButtons.forEach { (button, original) ->
            button.text = if (caps) original.uppercase() else original
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
