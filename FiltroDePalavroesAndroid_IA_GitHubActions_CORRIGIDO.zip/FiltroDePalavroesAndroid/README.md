# Filtro de Palavrões — protótipo Android

Este é um projeto-fonte de um teclado Android que substitui algumas palavras ofensivas por `****` quando a pessoa termina de digitá-las e pressiona espaço ou pontuação. Foi pensado para poder ser escolhido como teclado no WhatsApp, mas também pode ser usado em outros campos de texto.

## Importante

- **Agora usa IA local.** O teclado carrega um modelo pequeno (`app/src/main/assets/modelo_ia.txt`) que reconhece palavrões escritos de formas diferentes (m3rd4, merdaaa, f0d4-se, merdinha, caralhooo) e deixa passar palavras inocentes (cuidado, Curitiba, computador). Tudo roda no celular, sem internet.
- **Não é uma IA de linguagem completa.** É um classificador pequeno por palavra: não entende o sentido da frase inteira e pode errar em gírias novas. Palavras separadas por espaço (m e r d a) ou com pontos (p.o.r.r.a) não são pegas.
- **Só filtra texto digitado com este teclado.** Não edita mensagens recebidas, texto colado, áudio ou imagens.
- O código não declara permissão de internet e não envia mensagens para servidor.
- Teclados têm acesso ao que você digita. Não use para senhas.

## Melhorar a IA

1. Edite `ia/data/positivos.txt` (palavrões) e `ia/data/negativos.txt` (palavras normais que não podem ser filtradas).
2. Rode: `python3 ia/treinar.py ia app/src/main/assets/modelo_ia.txt` (precisa de numpy e scikit-learn).
3. Teste: `python3 ia/prever.py app/src/main/assets/modelo_ia.txt`.
4. Recompile o app.

## Como abrir e testar

1. Em um computador, instale o Android Studio e uma instalação do Gradle 8.9. Este ZIP contém o código-fonte, não um APK pronto nem o arquivo binário do Gradle Wrapper.
2. Na pasta do projeto, execute `gradle wrapper --gradle-version 8.9` para gerar o wrapper; depois abra a pasta `FiltroDePalavroesAndroid` no Android Studio e aguarde a sincronização.
3. Rode o app em um celular Android conectado por USB (com depuração USB ativada) ou em um emulador.
4. Abra o app **Filtro de Palavrões** e toque em **Abrir configurações de teclado**.
5. Ative **Teclado com Filtro**. O Android pode mostrar um aviso padrão sobre teclados de terceiros; leia-o com atenção.
6. Volte ao app e toque em **Escolher o Teclado com Filtro**. Depois abra o WhatsApp e selecione esse teclado pelo seletor de teclados do Android.
7. Teste uma palavrão seguido de espaço ou pontuação. Ela deverá aparecer como `****`.

## Requisitos

- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle 8.9 (o Android Studio pode baixar a distribuição configurada em `gradle/wrapper/gradle-wrapper.properties`)
